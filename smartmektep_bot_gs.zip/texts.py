
texts = {
    'kq': {
        'menu': [
            "📅 Sabaq kestesi",
            "👩‍🏫 Muǵallimler dіzimi",
            "📝 Arza",
            "🗣️ Pikir h'm usinis / Shikayat",
            "📚 Elektron kitaplar",
            "📞 Direktor menen baylanıs"
        ]
    }
}

links = {
    'kq_schedule': 'https://docs.google.com/spreadsheets/d/e/2PACX-1vT5Xvhlyk81XGTZz9xiq_kWAPiDDiXj1QhsVE6PPwFrKE15nyZGJw51BNPoeuvmf-rIy92GE2eHJwqv/pubhtml'
}
