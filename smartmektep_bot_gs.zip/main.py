
import logging
import gspread
from oauth2client.service_account import ServiceAccountCredentials
from telegram import Update, ReplyKeyboardMarkup
from telegram.ext import Updater, CommandHandler, MessageHandler, Filters, CallbackContext
from texts import texts, links

logging.basicConfig(level=logging.INFO)

def start(update: Update, context: CallbackContext):
    context.user_data['lang'] = 'kq'
    menu = texts['kq']['menu']
    keyboard = ReplyKeyboardMarkup([[btn] for btn in menu], resize_keyboard=True)
    update.message.reply_text("SmartMektep7Botqa Xosh kelipsiz!", reply_markup=keyboard)

def get_schedule(class_name):
    scope = ['https://spreadsheets.google.com/feeds', 'https://www.googleapis.com/auth/drive']
    creds = ServiceAccountCredentials.from_json_keyfile_name('service_account.json', scope)
    client = gspread.authorize(creds)
    sheet = client.open_by_url("https://docs.google.com/spreadsheets/d/e/2PACX-1vT5Xvhlyk81XGTZz9xiq_kWAPiDDiXj1QhsVE6PPwFrKE15nyZGJw51BNPoeuvmf-rIy92GE2eHJwqv/pub?output=xlsx")
    worksheet = sheet.worksheet(class_name)
    data = worksheet.get_all_values()
    result = "\n".join([" | ".join(row) for row in data])
    return result

def handle_menu(update: Update, context: CallbackContext):
    lang = context.user_data.get('lang', 'kq')
    text = update.message.text

    if text == "📅 Sabaq kestesi":
        update.message.reply_text("Qaysı sınıp? (mas: 5-A)")
        return
    elif "-" in text:
        try:
            schedule_text = get_schedule(text)
            update.message.reply_text(schedule_text)
        except Exception as e:
            update.message.reply_text("Kechirasiz, jadval topilmadi yoki xatolik yuz berdi.")
    elif text == "👩‍🏫 Muǵallimler dіzimi":
        update.message.reply_text("Muǵallimler dіzimi tez arada qosıladı.")
    elif text == "📝 Arza":
        update.message.reply_text("Arza túrlerin tańlań: Ruxsat soraw, Túsinіk xatı, Basqa mektepke kóshіrіw")
    elif text == "🗣️ Pikir h'm usinis / Shikayat":
        update.message.reply_text("Pikir hám shikayat jazıw ushın bul jerge jazıń:")
    elif text == "📚 Elektron kitaplar":
        update.message.reply_text("Qaysı pán boyınsha kitap izleysiz?")
    elif text == "📞 Direktor menen baylanıs":
        update.message.reply_text("Direktor: Daubaeva Bazargul Maxamatdinovna\n📞 Telefon: +998 91 264 29 29")
    else:
        update.message.reply_text("Túsinbey qaldım. Menyudan tanlań.")

BOT_TOKEN = "YOUR_BOT_TOKEN_HERE"

def main():
    updater = Updater(BOT_TOKEN, use_context=True)
    dp = updater.dispatcher

    dp.add_handler(CommandHandler("start", start))
    dp.add_handler(MessageHandler(Filters.text & ~Filters.command, handle_menu))

    updater.start_polling()
    updater.idle()

if __name__ == '__main__':
    main()
